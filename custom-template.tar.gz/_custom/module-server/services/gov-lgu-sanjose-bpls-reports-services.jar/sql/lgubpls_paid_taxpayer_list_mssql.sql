[getReport]
select 
	t2.*, b.orgtype, b.tradename, b.owner_name, b.owner_address_text as owner_address, 
	b.address_text as businessaddress, baddr.barangay_name 
from ( 
	select t1.*, 
		(select sum(decimalvalue) from business_application_info where applicationid=t1.applicationid and attribute_objid='CAPITAL') as capital, 
		(select sum(decimalvalue) from business_application_info where applicationid=t1.applicationid and attribute_objid='GROSS') as gross, 
		(
			select top 1 permitno from business_permit 
			where businessid=t1.objid and activeyear=t1.activeyear and state='ACTIVE'
			order by dtissued desc, version desc 
		) as permitno 
	from ( 
		select distinct 
			b.objid, p.applicationid, ba.appyear as activeyear, ba.apptype 
		from business_payment p  
			inner join business_application ba on ba.objid = p.applicationid 
			inner join business b on b.objid = ba.business_objid 
		where p.refdate >= $P{startdate} 
			and p.refdate < $P{enddate} 
			and ba.apptype in ( ${apptypefilter} ) 
			and b.permittype = $P{permittypeid} 
	)t1 
)t2 
	inner join business b on b.objid = t2.objid 
	left join business_address baddr on baddr.objid = b.address_objid 
order by b.tradename 
