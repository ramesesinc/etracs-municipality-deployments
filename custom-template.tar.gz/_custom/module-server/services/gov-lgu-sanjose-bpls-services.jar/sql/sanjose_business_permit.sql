[findOwnerInfo]
select 
	ei.objid as ownerid, 
	concat(ei.firstname,(case when ei.middlename is null then '' else concat(' ',ei.middlename) end),' ',ei.lastname) as ownerfullname 
from business b 
	inner join entityindividual ei on ei.objid = b.owner_objid 
where b.objid = $P{businessid}


[findOwnerAddress]
select a.* 
from entity e 
	inner join entity_address a on a.objid = e.address_objid 
where e.objid = $P{objid}
 