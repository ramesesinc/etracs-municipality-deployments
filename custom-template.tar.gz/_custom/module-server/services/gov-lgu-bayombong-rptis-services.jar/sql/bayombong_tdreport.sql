[getLandItems]
select 
	'land' as propertytype, 
	au.name as actualuse,
	lspc.name as specificclass,
	sub.name as subclass, 
	ld.area,
	spc.areatype,
	ld.marketvalue,
	ld.assesslevel,
	case when ld.taxable = 1 then 'T' else 'E' end as taxable,
	case when ld.taxable = 1 then ld.assessedvalue else null end as taxableav,
	case when ld.taxable = 0 then ld.assessedvalue else null end as exemptav,
	ld.assessedvalue
from faas f
	inner join landdetail ld on f.rpuid = ld.landrpuid 
	inner join landassesslevel au on ld.actualuse_objid = au.objid 
	inner join lcuvspecificclass spc on ld.specificclass_objid = spc.objid 
	inner join landspecificclass lspc on ld.landspecificclass_objid = lspc.objid 
	inner join lcuvsubclass sub on ld.subclass_objid = sub.objid 
where f.objid = $P{faasid}


[getBldgItems]
select 
	'bldg' as propertytype, 
	au.name as actualuse,
	lspc.name as specificclass,
	sub.name as subclass, 
	ld.area,
	spc.areatype,
	ld.marketvalue,
	ld.assesslevel,
	case when ld.taxable = 1 then 'T' else 'E' end as taxable,
	case when ld.taxable = 1 then ld.assessedvalue else null end as taxableav,
	case when ld.taxable = 0 then ld.assessedvalue else null end as exemptav,
	ld.assessedvalue
from faas f
	inner join landdetail ld on f.rpuid = ld.landrpuid 
	inner join landassesslevel au on ld.actualuse_objid = au.objid 
	inner join lcuvspecificclass spc on ld.specificclass_objid = spc.objid 
	inner join landspecificclass lspc on ld.landspecificclass_objid = lspc.objid 
	inner join lcuvsubclass sub on ld.subclass_objid = sub.objid 
where f.objid = $P{faasid}


[findPreviousAv]
select	
	case when ra.taxable = 1 then ra.assessedvalue else 0 end as taxableav,
	case when ra.taxable = 0 then ra.assessedvalue else 0 end as exemptav
from faas f
	inner join faas_previous p on f.objid = p.faasid
	inner join faas pf on p.prevfaasid = pf.objid 
	inner join rpu_assessment ra on pf.rpuid = ra.rpuid 
where f.objid = $P{faasid}