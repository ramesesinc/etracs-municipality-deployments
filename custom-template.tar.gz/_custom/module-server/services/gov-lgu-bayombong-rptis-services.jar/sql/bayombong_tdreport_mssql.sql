[getLandItems]
select 
	'land' as propertytype,
	au.name as actualuse,
	lspc.name as specificclass,
	sub.name as subclass, 
	sum(ld.area) as area,
	sum(ld.areaha) as areaha, 
	sum(ld.areasqm) as areasqm,
	spc.areatype,
	sum(ld.marketvalue) as marketvalue,
	ld.assesslevel,
	case when ld.taxable = 1 then 'T' else 'E' end as taxable,
	sum(case when ld.taxable = 1 then ld.assessedvalue else null end) as taxableav,
	sum(case when ld.taxable = 0 then ROUND((ld.marketvalue * ld.assesslevel)/100, -1) else null end) as exemptav,
	sum(case when ld.taxable = 1 then ROUND((ld.marketvalue * ld.assesslevel)/100, -1) end) as assessedvalue 
from faas f
	inner join faas_list fl on f.objid = fl.objid
	inner join landdetail ld on fl.rpuid = ld.landrpuid 
	inner join landassesslevel au on ld.actualuse_objid = au.objid 
	inner join lcuvspecificclass spc on ld.specificclass_objid = spc.objid
	inner join propertyclassification pc ON spc.classification_objid = pc.objid 
	inner join landspecificclass lspc on ld.landspecificclass_objid = lspc.objid 
	inner join lcuvsubclass sub on ld.subclass_objid = sub.objid
where f.objid =  $P{faasid}
group by
	au.name,
	lspc.name,
	sub.name,
	spc.areatype,
	ld.assesslevel,
	ld.taxable 



[getBldgItems]
select
	'BLDG' as propertytype,
	bk.name as bldgdescname,
	pc.code as classcode,
	pc.name as classification,
	bal.code as actualusecode,
	bal.name as actualuse,
	bu.area as area,
	'SQM' as areatype,
	case when r.useswornamount = 1 then ra.marketvalue else bu.marketvalue end as marketvalue,
	ra.assesslevel as assesslevel,
	case when bu.taxable = 1 then 'T' else 'E' end as taxable,
	case when bu.taxable = 1 then (
		case when r.useswornamount = 1 then ra.assessedvalue else ROUND((bu.marketvalue * ra.assesslevel)/100, -1) 
	end) else null end as taxableav,
	case when bu.taxable = 0 then (
		case when r.useswornamount = 1 then ROUND((bu.marketvalue * ra.assesslevel)/100, -1) else ROUND((bu.marketvalue * ra.assesslevel)/100, -1)
	end) else null end as exemptav,
	bu.taxable
from faas f
	inner join faas_list fl on f.objid = fl.objid
	inner join rpu r on fl.rpuid = r.objid 
	inner join rpu_assessment ra on r.objid = ra.rpuid
	inner join bldgrpu br on ra.rpuid = br.objid
	inner join propertyclassification pc on ra.classification_objid = pc.objid 
	inner join bldgassesslevel bal on ra.actualuse_objid = bal.objid
	inner join bldguse bu on br.objid = bu.bldgrpuid and ra.actualuse_objid = bu.actualuse_objid
	inner join bldgrpu_structuraltype bs on bu.bldgrpuid = bs.bldgrpuid and bu.structuraltype_objid = bs.objid
	inner join bldgkindbucc bucc on bs.bldgkindbucc_objid = bucc.objid 
	inner join bldgkind bk on bucc.bldgkind_objid = bk.objid
where f.objid = $P{faasid}


[getMachItems]
SELECT 
	'MACH' AS propertytype,
	pc.code AS classcode,
	pc.name AS classification,
	mal.code AS actualusecode,
	mal.name AS actualuse,
	r.areasqm AS area,
	'SQM' as areatype,
	r.marketvalue AS marketvalue,
	r.assesslevel,
	case when r.taxable = 1 then 'T' else 'E' end as taxable,
	case when r.taxable = 1 then r.assessedvalue else null end as taxableav,
	case when r.taxable = 0 then ROUND((r.marketvalue * r.assesslevel)/100, -1) else null end as exemptav,
	case when r.taxable = 1 then ROUND((r.marketvalue * r.assesslevel)/100, -1) end as assessedvalue,
	r.areasqm AS areasqm,
	r.areaha AS areaha,
	r.taxable AS taxable 
FROM faas f
	INNER JOIN faas_list fl on f.objid = fl.objid
	INNER JOIN rpu_assessment r ON fl.rpuid = r.rpuid
	INNER JOIN propertyclassification pc ON r.classification_objid = pc.objid 
	INNER JOIN machassesslevel mal ON r.actualuse_objid = mal.objid
WHERE f.objid = $P{faasid}	


[findPreviousAv]
select	
	case when ra.taxable = 1 then ra.assessedvalue else 0 end as taxableav,
	case when ra.taxable = 0 then ra.assessedvalue else 0 end as exemptav
from faas f
	inner join faas_previous p on f.objid = p.faasid
	left join faas pf on p.prevfaasid = pf.objid 
	left join rpu_assessment ra on pf.rpuid = ra.rpuid 
where f.objid = $P{faasid}


[findAppSign]
select
	sab.ry as asry,
	sab.barangayid as barangayid,
	sab.barangayname as barangayname,
	sab.signatoryid as appraiserobjid,
	sab.signatoryname as appraisername,
	sab.signatorytitle as appraisertitle
from faas_list fl
	inner join barangay b on fl.barangayid = b.objid
	inner join signatory_assign_barangay sab on fl.ry = sab.ry and fl.barangayid = sab.barangayid
where fl.objid = $P{faasid}
	and fl.txntype_objid = 'GR'