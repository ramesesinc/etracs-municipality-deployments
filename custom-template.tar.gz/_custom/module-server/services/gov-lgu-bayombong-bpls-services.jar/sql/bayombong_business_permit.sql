[getPaymentInfo]
select 
	sum(tax) as tax, sum(regfee) as regfee, sum(othercharge) as othercharge, 
	sum(amount) as amount, sum(amtpaid) as amtpaid, 
	(case when sum(amount) = sum(amtpaid) then 'FULL' else 'PARTIAL' end) as paymentmode 
from ( 
	select 
		(case when br.taxfeetype = 'TAX' then br.amount else 0.0 end) as tax, 
		(case when br.taxfeetype = 'REGFEE' then br.amount else 0.0 end) as regfee, 
		(case when br.taxfeetype = 'OTHERCHARGE' then br.amount else 0.0 end) as othercharge, 
		br.amount, br.amtpaid  
	from business_permit bper 
		inner join business_application ba on ba.objid = bper.applicationid 
		inner join business_receivable br on br.applicationid = ba.objid 
	where bper.objid = $P{permitid} 

	union all 

	select 
		(case when br.taxfeetype = 'TAX' then br.amount else 0.0 end) as tax, 
		(case when br.taxfeetype = 'REGFEE' then br.amount else 0.0 end) as regfee, 
		(case when br.taxfeetype = 'OTHERCHARGE' then br.amount else 0.0 end) as othercharge, 
		br.amount, br.amtpaid 
	from business_permit bper 
		inner join business_application ba on ba.objid = bper.applicationid 
		inner join business_application app on app.objid = ba.parentapplicationid
		inner join business_receivable br on br.applicationid = app.objid 
	where bper.objid = $P{permitid} 
)tmp1

[findBusiness]
select * from business where objid = $P{objid}